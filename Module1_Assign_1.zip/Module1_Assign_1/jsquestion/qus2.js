function qus2() {
	
	
	  
	
    let firstName = "", lastName = "", age = "";

    firstName = prompt("Enter your First Name : ");
    lastName = prompt("Enter your Last Name : ");
    age = prompt("Enter your Age Name : ");
    
     //var userInfo=(`Hello ${firstName} ${lastName}, I now know your ${age} years old.`);
     
    
     

    alert(`Hello ${firstName} ${lastName}, I now know your ${age} years old.`);
    
    

}