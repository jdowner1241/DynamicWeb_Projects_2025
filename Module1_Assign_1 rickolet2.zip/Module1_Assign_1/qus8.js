function qus7(){
    window.onload = function () {
    var imageElement = document.getElementById("image");
    imageElement.src = "mountain.jpg";
};
}