function qus7(){
    document.getElementById("options").addEventListener("change", function qus7() {
    let selectedValue = this.value;
    let message = "";

    switch (selectedValue) {
        case "1":
            message = "You selected Option 1!";
            break;
        case "2":
            message = "You selected Option 2!";
            break;
        case "3":
            message = "You selected Option 3!";
            break;
        default:
            message = "Please select an option.";
    }
    document.getElementById("message").textContent = message;
});
}