function qus6(){
    document.getElementById("btn1").addEventListener("click", function qus6() {
    let tutorialDivs = document.querySelectorAll(".tutorial");
    tutorialDivs.forEach(div => {
        div.style.backgroundColor = "yellow";
    });
});
}