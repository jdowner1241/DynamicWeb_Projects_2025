function qus2() {
    let firstName = "", lastName = "", age = "";

    firstName = prompt("Enter your First Name : ");
    lastName = prompt("Enter your Last Name : ");
    age = prompt("Enter your Age Name : ");

    alert(`Hello ${firstName} ${lastName}, I now know your ${age} years old.`);
}